<?php

$conexion=new mysqli("localhost", "root", "", "pw");
$conexion=new mysqli("localhost", "root", "", "pw");









?>