<!DOCTYPE html>
<html lang="en">
	<head>
		<meta charset="UTF-8" />
		<meta http-equiv="X-UA-Compatible" content="IE=edge" />
		<meta
			name="viewport"
			content="width=device-width, initial-scale=1.0"
		/>
		<title>PLAYTHING WORLD</title>
		<link rel="stylesheet" href="lol.css" />
	</head>
	<body>
		<header>
			<div class="container-hero" id="principio">
				
				<div class="container hero">
					<div class="customer-support">
						<i class="fa-solid fa-headset"></i>
						<div class="content-customer-support">
							<span class="text">Soporte Técnico</span>
							<span class="number">5618361640</span>
						</div>
					</div>

					<div class="container-logo">
						
						<img src="./Imagenes/LOGO VERTICAL.png" alt="">
					</div>

					<div class="container-user">
						<a href="finsesion.php"><?php echo $_SESSION['registro']; ?><i class="fa-solid fa-user"></a></i>
						<ul>
                            <li><a href="perfil.php">Mi perfil</a></li>
                            <li><a href="salir.php">Cerrar Sesion</a></li>
</ul>
					</div>
				</div>
			</div>

			<div class="container-navbar">
				<nav class="navbar container">
					<i class="fa-solid fa-bars"></i>
					<ul class="menu">
						<li><a href="#inicio">Inicio</a></li>
						<li><a href="#producto">Nuestro producto</a></li>
						<li><a href="#GAL">Galeria</a></li>
						<li><a href="#qn">¿Quiénes somos?</a></li>
						<li><a href="#redes">Redes sociales</a></li>
						<li><a href="Mi cuenta.html">Mi cuenta</a></li>
					</ul>

					<form class="search-form">
						<input type="search" name="buscador" id="buscador"  placeholder="Buscar..." />
						<button class="btn-search">
							<i class="fa-solid fa-magnifying-glass"></i>
						</button>
					</form>
				</nav>
			</div>
		</header>
		
<section class="banner">
	<div class="content-banner" id="inicio">
		<p>PLAYTHING WORLD</p>
		<h2>La sensación de enseñanza y alegría<br></h2>
		<a href="#">Bienvenid@</a>
	</div>
</section>

<main class="main-content">
	<section class="container container-features">
		<div class="card-feature">
<i class="fa-solid fa-plane-up"></i>
<div class="feature-content">
	<span>Envíos a toda la República Mexicana</span>
	<p>Próximamente envíos Internacionales</p>
</div>
		</div>
		<div class="card-feature">
			<i class="fa-solid fa-headset"></i>
			<div class="feature-content">
				<span>Atención y soporte</span>
				<p>Las 24 horas y los 7 días de la semana</p>
			</div>
					</div>
					<div class="card-feature">
						<i class="fa-solid fa-bag-shopping"></i>
						<div class="feature-content">
							<span>Devolución Inmediata</span>
							<p>Garantía de 3 meses</p>
						</div>
								</div>
								<div class="card-feature">
									<i class="fa-solid fa-tag"></i>
									<div class="feature-content">
										<span>Ofertas por temporada</span>
										<p>Desde el 10% hasta el 50% de descuento</p>
									</div>
											</div>
	</section>
	<section class="container top-categories">
		<h1 class="heading-1">Nuestro producto</h1>
		<div class="container-categories">
			
			<div class="card-category category-modelo2" id="producto">
				<p>Paquete PW</p>
				<a href="Paquete PW.html" class="o"><span href="Paquete PW.html">Ver más</span></a>
			</div>
			
		</div>
	</section>
	<h1 class="heading-1"  id="GAL">Galeria de Imagenes</h1>
	<br>
	<br>
	<br><section class="gallery">
<img src="Imagenes/IMG-20240305-WA0083.jpg" class="gallery-img-1" alt="Gallery Img1">
<img src="Imagenes/IMG-20240305-WA0090.jpg" class="gallery-img-2" alt="Gallery Img2">
<img src="Imagenes/IMG-20240305-WA0091.jpg" class="gallery-img-3" alt="Gallery Img3">
<img src="Imagenes/IMG-20240305-WA0040.jpg" class="gallery-img-4" alt="Gallery Img4">
<img src="Imagenes/IMG-20240305-WA0041.jpg" class="gallery-img-5" alt="Gallery Img5">
<img src="Imagenes/IMG-20240305-WA0043.jpg" class="gallery-img-6" alt="Gallery Img6">
<img src="Imagenes/IMG-20240305-WA0044.jpg" class="gallery-img-7" alt="Gallery Img7">
<img src="Imagenes/IMG-20240305-WA0045.jpg" class="gallery-img-8" alt="Gallery Img8">
<img src="Imagenes/IMG-20240305-WA0048.jpg" class="gallery-img-9" alt="Gallery Img9">
<img src="Imagenes/IMG-20240305-WA0053.jpg" class="gallery-img-10" alt="Gallery Img10">
<img src="Imagenes/IMG-20240305-WA0039.jpg" class="gallery-img-11" alt="Gallery Img11">
<img src="Imagenes/IMG-20240305-WA0055.jpg" class="gallery-img-12" alt="Gallery Img12">
<img src="Imagenes/IMG-20240305-WA0096.jpg" class="gallery-img-13" alt="Gallery Img13">
</section>

<section class="container blogs" id="qn">
	<h1 class="heading-1">¿Quiénes somos?</h1>

	<div class="container-blogs">
		<div class="card-blog">
			<div class="container-img">
				<img src="Imagenes/icono-misión.png" alt="Imagen Blog 1" />
				<div class="button-group-blog">
				</div>
			</div>
			<div class="content-blog">
				<h3>MISION</h3>
				<span>5 de abril del 2024</span>
				<p>
					<strong>Misión.</strong>
Crear productos eficientes y originales, que ayuden a la estimulación temprana de los niños y reduzca
el estrés en jóvenes y/o adultos, dándole un reúso a materiales antes usados, con la mejor calidad
sin dañar el ambiente.
				</p>
			</div>
		</div>
		
		<div class="card-blog">
			<div class="container-img">
				<img src="Imagenes/icono-vision.png" alt="Imagen Blog 3" />
				<div class="button-group-blog">
				</div>
			</div>
			<div class="content-blog">
				<h3>VISION</h3>
				<span>5 de abril del 2024</span>
				<p>
					<strong>Visión.</strong>
					Ser la empresa favorita de los niños y de confianza para los padres, haciendo realidad sus sueños;
					reconocida en la elaboración de productos ecológicos e innovadores, que ayuden a la reducción
					de contaminación.
				</p>
			</div>
		</div>
		<div class="card-blog">
			<div class="container-img">
				<img src="Imagenes/2024-03-16.png" alt="Imagen Blog 3" />
				<div class="button-group-blog">
				</div>
			</div>
			<div class="content-blog">
				<h3>NUESTRA ETICA</h3>
				<span>5 de abril del 2024</span>
				<p>
					<strong>Ética.</strong>
Nuestros kits didácticos deberán estar elaborados con materiales que sean seguros e inofensivos
para la salud de nuestro cliente. Además de ser productos de la mejor calidad.
				</p>
			</div>
		</div>
	</div>
</section>
</main>

<footer class="footer">
	<div class="container container-footer">
		<div class="menu-footer">
			<div class="contact-info" id="redes">
				<p class="tittle-footer">Contacto</p>
				<ul><li>Dirección: Av. Casa de la Moneda 133, Col. Lomas de Sotelo, Alcaldía Miguel Hidalgo, C.P. 11200, Ciudad de México, México.</li>
				<li>Teléfono: 56 1836 1640</li>
				<li>Correo: playthingworldd@gmail.com</li>
			</ul>
			<div class="social-icons">
				<span class="Facebook"><a href="https://www.facebook.com/profile.php?id=61554541266690" class="o"><i class="fa-brands fa-facebook-f"></i></a></span>
				<span class="Twitter"><i class="fa-brands fa-twitter"></i></span>
				<span class="TikTok"><i class="fa-brands fa-tiktok"></i></span>
				<span class="Instagram"><a href="https://www.instagram.com/plaything_world"><i class="fa-brands fa-instagram"></i></a></span>
			</div>
			</div>
			<div class="informacion">
				<p class="tittle-footer">Información</p>
				<ul>
					<li><a href="Documentos PW/ACERCA DE.pdf" download="Acerca de">Acerca de</a></li>
					<li><a href="Documentos PW/COPYRIGHT.pdf" download="Copyright">Copyright</a></li>
					<li><a href="Documentos PW/LICENCIA DE USO.pdf" download="Licencia de uso">Licencia de uso</a></li>
					<li><a href="Documentos PW/TERMINOS Y CONDICIONES.pdf" download="Términos y condiciones">Términos y condiciones</a></li>
					<li><a href="Documentos PW/POLITICAS DE PRIVACIDAD.pdf" download="Políticas de privacidad">Políticas de privacidad</a></li>
				</ul>
			</div>

			<div class="my-account">
				<p class="tittle-footer">Mi cuenta</p>

				<ul>
					<li><a href="Mi cuenta.html">Mi cuenta</a></li>
					<li><a href="Documentos PW/FACTURAS Y REEMBOLSOS.pdf" download="Facturas">Facturas</a></li>
					<li><a href="Documentos PW/FACTURAS Y REEMBOLSOS.pdf" download="Reembolsos">Reembolsos</a></li>
				</ul>
			</div>
			<div class="newsletter">
				<p class="tittle-footer">Boletín</p>
				<div class="content">
					<p>Suscribete a nuestro boletín y mantente al tanto de nuestras actualizaciones</p>
					<input type="email" placeholder="Ingresa tu correo">
					<button>Suscribete</button>
				</div>
			</div>
		</div>
		<div class="copyright">
			<p>Desarrollado por: Cruz Martínez Jocelyn, Ochoa Puga Ángeles Azucena, Rodríguez Arenas Ángel Nikolas 
				y Rodríguez de la Cruz Dulce Lizbeth los creadores de PLAYTHING WORLD. Todos los derechos reservados &copy; 2024
			</p>
			
		</div>
	</div>
	<a href="#principio"><img src="Imagenes/arriba.png" id="botonArriba"></a>
</footer>


    <script
        src="https://kit.fontawesome.com/81581fb069.js"
        crossorigin="anonymous"
		></script>
		<script
        src="busqueda.js"
		></script>
</body>
</html>